#!/bin/sh
STATE_OK=0
STATE_WARNING=1
STATE_CRITICAL=2
STATE_UNKNOWN=3

error_name=`rsh $1 cat $2 |grep error`

if [ "$error_name" = "" ]
then
        echo "OK no error"
	STATE_OK=0
else 
   echo "WARNING $error_name "
        exit 1
fi
