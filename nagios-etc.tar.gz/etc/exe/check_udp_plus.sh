#!/bin/sh
# $1 ServerIP
# S4 UDP Port
# if succeeded ,$?=0,but $?=1
# view $? ,use "echo $?"
/usr/bin/nc -uz -w1 $1 $2 |grep succeeded >/dev/null
if [ $? -eq 0 ]
   then
      echo "$1 udp-port $2 succeeded"
      exit 0
   else
      echo "$1 udp-port $2 failed"
      exit 2
fi
