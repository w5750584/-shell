#!/bin/bash
if [ $? = 0 ] 
then
	#echo $html
	chk=`curl -s http://new.2bulu.com | grep "<title>" | cut -c8-10`
	if [ "$chk" = "两步路" ]
	then
		echo "两步路new.2bulu.com ok!"
		exit 0
	else
		echo "两步路new.2bulu.com 业务故障 "
		exit 1
	fi
else
	echo "两步路new.2bulu.com 网络故障"
	exit 3
fi

