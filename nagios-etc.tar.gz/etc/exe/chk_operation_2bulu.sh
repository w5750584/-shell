#!/bin/bash
if [ $? = 0 ] 
then
	#echo $html
	chk=`curl -s http://operation.2bulu.com:20080/login/forward_login.htm | grep '<title>' | cut -c9-10`
	if [ "$chk" = "登录" ]
	then
		echo "俩步路后台operation.2bulu.com ok!"
		exit 0
	else
		echo "俩步路后台operation.2bulu.com 业务故障"
		exit 1
	fi
else
	echo "俩步路后台operation.2bulu.com 网络故障"
	exit 3
fi

