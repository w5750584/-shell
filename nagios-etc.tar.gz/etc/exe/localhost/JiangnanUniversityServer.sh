#!/bin/sh
STATE_OK=0
STATE_WARNING=1
STATE_CRITICAL=2
STATE_UNKNOWN=3

program=`ps -ef | grep -v grep |grep -v sh | grep JiangnanUniversityServer | awk 'NR==1'`
program_name=`echo $program |awk '{print $10}'`
#echo $program
#echo $program_name
if [ "$program_name" = "JiangnanUniversityServer.jar" ]
then
	echo "OK $program_name Program is running"
	STATE_OK=0
else
	echo "WARNING $program_name The program has been discontinued"
	exit 1
fi
