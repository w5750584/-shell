#!/bin/sh
cpu_s=`vmstat |awk 'NR==3 {print $15}'`
cpu_y=`expr 100 - $cpu_s`
STATE_OK=0
STATE_WARNING=1
STATE_CRITICAL=2
STATE_UNKNOWN=3

if [ "$cpu_y" -gt "80" ]
then
        echo "WARNING The CPU usage $cpu_y %"
        exit 1
else
   echo "OK  The CPU usage $cpu_y % |$cpu_y;80;90;0;100"
        STATE_OK=0
fi
