#!/bin/sh
STATE_OK=0
STATE_WARNING=1
STATE_CRITICAL=2
STATE_UNKNOWN=3


user=root
password=root
host=113.57.230.36
mysql_connection=`mysql -h$host -u$user -p$password -e "show status like 'Threads_connected';" |awk 'NR==2 {print $2}'`

if [ "$mysql_connection" -gt "8000" ]
then
	echo "Warning mysql number of connections to over $mysql_connection |mysql=$mysql_connection;8000;9000;0;10000"
	exit 0
else
	echo "OK Current mysql connection number is $mysql_connection |mysql=$mysql_connection;8000;9000;0;10000"
	exit 0
fi
