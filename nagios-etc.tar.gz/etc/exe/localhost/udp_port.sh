#!/bin/sh
STATE_OK=0
STATE_WARNING=1
STATE_CRITICAL=2
STATE_UNKNOWN=3
port=$1
port_name=`netstat -anlu |grep $port |awk '{print $4}'`
#program_name=`echo $program |awk '{print $10}'`
#echo $program
#echo $program_name
if [ "$port_name" = "" ]
then
        echo "WARNING $port_name The program has been discontinued"
        exit 1
else 
   echo "OK  $port_name Program is running"
        STATE_OK=0
fi
